# CS 3270 Python Software Develpment 

## Module 2 - Phase 2
This Phase references Modularization, this phase is meant to give experience interacting with the Python ecosystem in a standard way.

### First Task
Write code to give descriptive statistics such as mean, median, mode, range etc.

### Second Task
Modularize the code. Build and publish a package using the procedures described in Chapter 2 of the textbook to TestPyPI.

### Third Task 
Install and use the package in the code as the installation would be in any official Python library.

## Module 1 - Phase 1

This module is the introduction of Python Software Develpment. 

Cmd+Shift+V to preview Markdown in VS Code.

### First Task

Create the environment for the Pythonista Culture, installing and implementing [Github Copilot](https://github.com/features/copilot) to implelemnt LLM tools to assist with our code.


### Second Task
Test the project and the IDE by creating a simple function 'def print_hi' and call that function in the `if __name__ == '__main__':` conditional statement.

### Third Task
Download a Dataset, add it to our project folder, open it and also allow writting into the dataset if needed. The dataset was downloaded from [Kaggle - Australian Weather](https://www.kaggle.com/datasets/arunavakrchakraborty/australia-weather-data).

One functions was created for open the CSV file and convert it into DataFrame using the pandas library.
## Installations
```python
pip install pandas
pip install setuptools wheel
python 
```
## Imports

```python
import pandas as pd
```

## Author
Created for David Ariza, Computational Data Science, UVU.
Course: CS-3270.