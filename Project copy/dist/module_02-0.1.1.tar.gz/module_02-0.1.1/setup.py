from setuptools import setup, find_packages

setup(
    name='module_02',
    version='0.1.1',
    packages=find_packages(),
    install_requires=[
        'pandas>=1.0.0',
    ],
    author='David Ariza',
    author_email='daarizac@gmail.com',
    description='A modular Python project for data analysis',
    url='https://github.com/davidariza4441/CS-3270-Project',
    classifiers=[
        'Programming Language :: Python :: 3',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',
)